package com.samplepaper.dsm;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.AttributedCharacterIterator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import static android.content.ContentValues.TAG;

public class Firebasedata extends AppCompatActivity {

    ListView firebasedatalist;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    List<DocumentSnapshot> orderList = new ArrayList<>();

    String date;
    List<String> data = new ArrayList<String>();


    SwipeRefreshLayout refresh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebasedata);

        refresh = (SwipeRefreshLayout) findViewById(R.id.refresh);

        refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {



                        refresh.setRefreshing(false);

                        data.clear();

                        db.collection("attendanceData").document(date).collection("attendance")
                                .whereEqualTo("date",date)
                                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                                    @Override
                                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                                        for(DocumentSnapshot snap : queryDocumentSnapshots){

                                            data.add(snap.getString("date"));

                                        }

                                    }

                                });

                        db.collection("attendanceData").document(date).collection("attendance")
                                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                                    @Override
                                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                                        for(DocumentSnapshot snap : queryDocumentSnapshots){

                                            data.add(snap.getString("name"));

                                        }
                                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,data);
//                        adapter.notifyDataSetChanged();
                                        firebasedatalist.setAdapter(adapter);

                                    }

                                });
                    }
                },2000);
            }
        });


        firebasedatalist = (ListView) findViewById(R.id.firebasedatalist);

        SimpleDateFormat format = new SimpleDateFormat("dd-M-yyyy");
        date = format.format(new Date());



        db.collection("attendanceData").document(date).collection("attendance")
                .whereEqualTo("date",date)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                        for(DocumentSnapshot snap : queryDocumentSnapshots){

                            data.add(snap.getString("date"));

                        }

                    }

                });

        db.collection("attendanceData").document(date).collection("attendance")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                        for(DocumentSnapshot snap : queryDocumentSnapshots){

                            data.add(snap.getString("name"));

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,data);
//                        adapter.notifyDataSetChanged();
                        firebasedatalist.setAdapter(adapter);

                    }

                });



    }
}
