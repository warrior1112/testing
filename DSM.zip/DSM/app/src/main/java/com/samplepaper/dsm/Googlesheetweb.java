package com.samplepaper.dsm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;

public class Googlesheetweb extends AppCompatActivity {

    WebView googlesheetweb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_googlesheetweb);

//        googlesheetweb = (WebView) findViewById(R.id.googlesheetweb);
//        googlesheetweb.loadUrl("https://docs.google.com/spreadsheets/d/1rpzvz1-3a7597xQN2HeWvf_XEG-v1tiOEW-2FBz5LMs/edit?usp=sharing");

        Uri uri = Uri.parse("https://docs.google.com/spreadsheets/d/1rpzvz1-3a7597xQN2HeWvf_XEG-v1tiOEW-2FBz5LMs/edit?usp=sharing");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
}
