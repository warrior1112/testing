package com.samplepaper.dsm;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button takeattendance, googlesheet, share, firebasedata;

    FirebaseFirestore db = FirebaseFirestore.getInstance();  //1

    List<DocumentSnapshot> orderList = new ArrayList<>();    //2

    String date;                                             //3
    List<String> data = new ArrayList<String>();                   //4

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        takeattendance = (Button) findViewById(R.id.takeattendance);
        takeattendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Faceapiweb.class);
                startActivity(i);
            }
        });

        googlesheet = (Button) findViewById(R.id.gotosheet);
        googlesheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Googlesheetweb.class);
                startActivity(i);
            }
        });

        share = (Button) findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.putExtra(Intent.EXTRA_SUBJECT, "Attendance Sheet");
                i.putExtra(Intent.EXTRA_TEXT, "https://docs.google.com/spreadsheets/d/1rpzvz1-3a7597xQN2HeWvf_XEG-v1tiOEW-2FBz5LMs/edit?usp=sharing");
                i.setType("text/plane");
                startActivity(Intent.createChooser(i, "send today's attendance"));

            }
        });




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        SimpleDateFormat format = new SimpleDateFormat("dd-M-yyyy");
        date = format.format(new Date());

        db.collection("attendanceData").document(date).collection("attendance")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                        for(DocumentSnapshot snap : queryDocumentSnapshots){

                            data.add(snap.getString("name"));

                        }

                    }

                });

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






        firebasedata = (Button) findViewById(R.id.firebasedata);
        firebasedata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,PA.class);
                Bundle namesarray = new Bundle();
                namesarray.putSerializable("ARRAYLIST",(Serializable)data);
                i.putExtra("namesarray",namesarray);
                startActivity(i);
            }
        });

    }
}
