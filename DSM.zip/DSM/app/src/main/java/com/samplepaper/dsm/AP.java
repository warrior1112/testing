package com.samplepaper.dsm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class AP extends AppCompatActivity {

    ArrayList<String> allstudents = new ArrayList<>();
    ArrayList<String> clearedData = new ArrayList<>();
    ArrayList<String> absentstuds = new ArrayList<>();

    ListView displayabsents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_p);

        allstudents.add("Aman-ahmad-Rollno-10");
        allstudents.add("Huzaifa-siddiqui-Rollno-7");
        allstudents.add("Jagruti-patil-Rollno-4");
        allstudents.add("jannat-shaikh-Rollno-6");
        allstudents.add("Jyoti-mallah-Rollno-2");
        allstudents.add("Kanad-patil-Rollno-3");
        allstudents.add("Kishor-jena-Rollno-8");
        allstudents.add("Mansi-gharat-Rollno-15");
        allstudents.add("Preeti-verma-Rollno-14");
        allstudents.add("Rahul-chauhan-Rollno-13");
        allstudents.add("Rajashree-pachpande-Rollno-1");
        allstudents.add("Ramu-mallah-Rollno-12");
        allstudents.add("Rekha-gupta-Rollno-16");
        allstudents.add("Shabista-shaikh-Rollno-5");
        allstudents.add("Siddharth-misra-Rollno-17");
//        allstudents.add("Aman-ahmad-Rollno-10");


        Intent get = getIntent();
        Bundle namesarray = get.getBundleExtra("namesarray");
        final ArrayList<String> names = (ArrayList<String>) namesarray.getSerializable("ARRAYLIST");

        clearedData = new ArrayList<>();
        for(int i = 0; i<names.size(); i++){

            clearedData.add(names.get(i).replaceAll("\\(.*\\)","").trim());

        }

        int c = 1;

        for(int i = 0 ; i<allstudents.size(); i++){

                if(clearedData.contains(allstudents.get(i).trim())){
                    System.out.println(c);
                    c++;
                }else {
                    absentstuds.add(allstudents.get(i));
                }

        }


        displayabsents = (ListView) findViewById(R.id.absentstuds);
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,absentstuds);
        displayabsents.setAdapter(adapter);

    }
}
