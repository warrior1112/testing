package com.samplepaper.dsm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;
import java.util.ArrayList;

public class PA extends AppCompatActivity {

    Button present,absent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p);


        Intent get = getIntent();
        Bundle namesarray = get.getBundleExtra("namesarray");
        final ArrayList<String> names = (ArrayList<String>) namesarray.getSerializable("ARRAYLIST");


        present = (Button) findViewById(R.id.present);
        present.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PA.this,Firebasedata.class);
                startActivity(i);
            }
        });

        absent = (Button) findViewById(R.id.absent);
        absent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PA.this,AP.class);
                Bundle namesarray = new Bundle();
                namesarray.putSerializable("ARRAYLIST",(Serializable)names);
                i.putExtra("namesarray",namesarray);
                startActivity(i);
            }
        });


    }
}
