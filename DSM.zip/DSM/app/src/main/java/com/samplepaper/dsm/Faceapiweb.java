package com.samplepaper.dsm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;

import java.security.Permission;

public class Faceapiweb extends AppCompatActivity {

    WebView faceapiweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faceapiweb);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},101);
        }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.INTERNET},102);
        }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA},103);
        }

//        faceapiweb = (WebView) findViewById(R.id.faceapiweb);
//        faceapiweb.getSettings().setJavaScriptEnabled(true);
//        faceapiweb.getSettings().setBuiltInZoomControls(true);
//        faceapiweb.getSettings().setAllowFileAccess(true);
//        faceapiweb.loadUrl("https://digitalsm.000webhostapp.com/");

        Uri uri = Uri.parse("https://digitalsm.000webhostapp.com/");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);

    }
}
